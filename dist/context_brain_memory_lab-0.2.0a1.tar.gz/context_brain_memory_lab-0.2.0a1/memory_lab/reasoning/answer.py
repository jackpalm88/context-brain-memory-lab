from __future__ import annotations

import re
from typing import Any, Optional

from memory_lab.context_packs.models import ContextPackBuildResponse
from memory_lab.providers.llm_backend import LLMBackend, LLMRequest
from memory_lab.providers.noop import NoopLLMBackend
from memory_lab.reasoning.explain import BASE_LIMITATIONS, BASE_NON_CLAIMS, build_conflict_warnings
from memory_lab.reasoning.models import ReasoningAnswerResponse, ReasoningProviderMetadata, ReasoningRequest
from memory_lab.reasoning.traverse import build_traversal_steps, collect_evidence_refs

FORBIDDEN_PUBLIC_FIELD_NAMES = {"verdict", "truth_decision", "resolution", "winner", "canonical_truth"}
FORBIDDEN_PROVIDER_TERMS = {"verdict", "truth decision", "resolution", "winner", "canonical truth"}
EVIDENCE_ID_PATTERN = re.compile(r"\bev_[A-Za-z0-9_-]+\b")

ANSWER_LIMITATIONS = [
    "B14 returns an evidence-grounded answer candidate only.",
    "The answer candidate is not a truth decision, verdict, or conflict resolution.",
    "Provider wording is disabled unless explicitly requested and configured.",
]

ANSWER_NON_CLAIMS = [
    "no_verdict",
    "no_truth_decision",
    "no_resolution",
    "no_winner",
    "no_canonical_truth",
    "no_private_ask_v2_port",
    "no_private_prompt_copy",
    "no_provider_call_by_default",
    "no_conflict_resolution",
    "no_full_context_brain_claim",
    "no_top_level_answer_field",
]


def _context_pack_ref(context_pack: ContextPackBuildResponse) -> dict[str, Any]:
    return {
        "context_pack_id": context_pack.context_pack_id,
        "workspace_id": context_pack.workspace_id,
        "query": context_pack.query,
        "scope": context_pack.scope,
        "pack_version": context_pack.summary_metadata.pack_version,
    }


def _reasoning_id(context_pack: ContextPackBuildResponse, request: ReasoningRequest, provider_attempted: bool) -> str:
    suffix = "provider" if provider_attempted else "deterministic"
    return f"rsn_answer_{context_pack.context_pack_id}_{request.max_hops}_{suffix}"


def _snippet(ref: dict[str, Any]) -> str:
    text = str(ref.get("snippet") or "").strip()
    text = " ".join(text.split())
    if len(text) > 240:
        return text[:237].rstrip() + "..."
    return text


def _has_usable_evidence(evidence_refs: list[dict[str, Any]]) -> bool:
    return any(_snippet(ref) for ref in evidence_refs)


def _usable_refs(evidence_refs: list[dict[str, Any]], roles: set[str | None] | None = None) -> list[dict[str, Any]]:
    refs: list[dict[str, Any]] = []
    for ref in evidence_refs:
        if roles is not None and ref.get("role") not in roles:
            continue
        if _snippet(ref):
            refs.append(ref)
    return refs


def _cited_snippet(ref: dict[str, Any]) -> str:
    evidence_id = str(ref.get("evidence_id") or "").strip()
    if not evidence_id:
        return _snippet(ref)
    return f"[{evidence_id}] {_snippet(ref)}"


def build_answer_candidate(
    *,
    context_pack: ContextPackBuildResponse,
    evidence_refs: list[dict[str, Any]],
    conflict_warnings: list[str],
) -> tuple[str, Optional[str]]:
    """Build a deterministic public answer candidate from evidence refs only."""
    if not _has_usable_evidence(evidence_refs):
        return (
            "Insufficient public evidence to produce an evidence-grounded answer candidate for this query or scope.",
            "insufficient_evidence",
        )

    support = _usable_refs(evidence_refs, {"support", None})
    current = _usable_refs(evidence_refs, {"current_state"})
    counter = _usable_refs(evidence_refs, {"counterfinding", "contradicting"})
    stale = [ref for ref in evidence_refs if (ref.get("is_current") is False or ref.get("cs_supersedes_content_id")) and _snippet(ref)]

    parts: list[str] = ["Based on the public evidence refs in this context pack, the answer candidate is:"]
    selected = (support or current or counter or stale)[:3]
    parts.append(" ".join(_cited_snippet(ref) for ref in selected))
    if current:
        parts.append("Current-state signals are included as evidence signals, not as automatic proof that other evidence is false.")
    if counter or stale or conflict_warnings:
        parts.append("Conflict, counterfinding, or stale signals require human review and are not resolved by this endpoint.")
    parts.append("This candidate is bounded by the supplied evidence refs and limitations.")
    return " ".join(parts), None


def _provider_metadata_without_call() -> ReasoningProviderMetadata:
    return ReasoningProviderMetadata(provider="none", attempted=False, configured=False, degraded=False)


def _provider_failure_reason(response) -> str:
    if getattr(response, "failure_reason", None):
        return str(response.failure_reason.value)
    return "provider_degraded"


def _provider_text_allowed(text: str) -> bool:
    lowered = text.lower()
    return bool(text.strip()) and not any(term in lowered for term in FORBIDDEN_PROVIDER_TERMS)


def _evidence_id(ref: dict[str, Any]) -> str:
    return str(ref.get("evidence_id") or "").strip()


def _provider_citations_allowed(text: str, evidence_refs: list[dict[str, Any]]) -> bool:
    allowed = {_evidence_id(ref) for ref in evidence_refs if _evidence_id(ref)}
    cited = set(EVIDENCE_ID_PATTERN.findall(text))
    return cited <= allowed


def provider_synthesize_answer_candidate(
    *,
    request: ReasoningRequest,
    deterministic_candidate: str,
    evidence_refs: list[dict[str, Any]],
    conflict_warnings: list[str],
    backend: Optional[LLMBackend] = None,
    provider_synthesis_enabled: bool = True,
) -> tuple[str, ReasoningProviderMetadata, Optional[str], str]:
    """Try explicitly opted-in provider wording through the public LLMBackend ABC only."""
    if not request.enable_provider_synthesis:
        return deterministic_candidate, _provider_metadata_without_call(), None, "deterministic"
    if not provider_synthesis_enabled:
        metadata = ReasoningProviderMetadata(provider="none", attempted=False, configured=False, degraded=True, failure_reason="provider_disabled")
        return deterministic_candidate, metadata, "provider_disabled", "degraded"

    llm = backend or NoopLLMBackend()
    metadata = ReasoningProviderMetadata(
        provider=llm.provider_name,
        attempted=True,
        configured=llm.is_configured,
        degraded=False,
    )
    citation_ids = [_evidence_id(ref) for ref in evidence_refs if _evidence_id(ref)]
    prompt = (
        "Produce a concise evidence-grounded answer_candidate from these evidence snippets only. "
        "Do not decide truth. Do not choose a winner. Do not resolve conflicts. "
        "If citing evidence, cite only these evidence_id values exactly: "
        f"{citation_ids[:5]}.\n\n"
        f"Deterministic candidate:\n{deterministic_candidate}\n\n"
        f"Evidence refs:\n{evidence_refs[:5]}\n\n"
        f"Warnings:\n{conflict_warnings}"
    )
    response = llm.summarize(
        LLMRequest(
            prompt=prompt,
            system="Public B14 answer-candidate wording only. No private prompts. No conflict decision.",
            max_tokens=192,
            temperature=0.0,
        )
    )
    metadata.model = response.model or None
    if response.degraded:
        metadata.degraded = True
        metadata.failure_reason = _provider_failure_reason(response)
        return deterministic_candidate, metadata, metadata.failure_reason, "degraded"
    text = str(response.text or "").strip()
    if not _provider_text_allowed(text) or not _provider_citations_allowed(text, evidence_refs):
        metadata.degraded = True
        metadata.failure_reason = "provider_output_rejected"
        return deterministic_candidate, metadata, metadata.failure_reason, "degraded"
    return text, metadata, None, "provider_backed"


def answer_context_pack(
    *,
    context_pack: ContextPackBuildResponse,
    request: ReasoningRequest,
    backend: Optional[LLMBackend] = None,
    provider_synthesis_enabled: bool = True,
) -> ReasoningAnswerResponse:
    steps = build_traversal_steps(context_pack, request)
    evidence_refs = collect_evidence_refs(context_pack)
    conflict_warnings = build_conflict_warnings(context_pack)
    deterministic_candidate, deterministic_degraded_reason = build_answer_candidate(
        context_pack=context_pack,
        evidence_refs=evidence_refs,
        conflict_warnings=conflict_warnings,
    )

    if deterministic_degraded_reason:
        provider_metadata = _provider_metadata_without_call()
        mode = "degraded"
        answer_candidate = deterministic_candidate
        degraded_reason = deterministic_degraded_reason
    else:
        answer_candidate, provider_metadata, provider_degraded_reason, mode = provider_synthesize_answer_candidate(
            request=request,
            deterministic_candidate=deterministic_candidate,
            evidence_refs=evidence_refs,
            conflict_warnings=conflict_warnings,
            backend=backend,
            provider_synthesis_enabled=provider_synthesis_enabled,
        )
        degraded_reason = provider_degraded_reason

    limitations = list(dict.fromkeys(BASE_LIMITATIONS + ANSWER_LIMITATIONS))
    non_claims = list(dict.fromkeys(list(context_pack.non_claims) + BASE_NON_CLAIMS + ANSWER_NON_CLAIMS))
    return ReasoningAnswerResponse(
        reasoning_id=_reasoning_id(context_pack, request, provider_metadata.attempted),
        mode=mode,
        answer_candidate=answer_candidate,
        evidence_refs=evidence_refs,
        context_pack_ref=_context_pack_ref(context_pack),
        traversal_steps=steps,
        conflict_warnings=conflict_warnings,
        limitations=limitations,
        provider_metadata=provider_metadata,
        degraded_reason=degraded_reason,
        non_claims=non_claims,
    )
