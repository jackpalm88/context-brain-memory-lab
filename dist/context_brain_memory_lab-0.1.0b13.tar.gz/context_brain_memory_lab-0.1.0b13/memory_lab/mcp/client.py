"""PR1B/P3C MCP API-backed client for local minimal API only.

Scope boundary:
- Local-only HTTP calls to minimal API runtime endpoints.
- No DB direct access.
- No provider/LLM paths.
- No external network calls.

P3C workspace boundary:
- Optional per-call workspace_id is transported as X-Workspace-ID.
- Optional MEMORY_LAB_MCP_DEFAULT_WORKSPACE_ID is a client-side default.
- If neither is set, no workspace header is sent and the API keeps its P3B
  MEMORY_LAB_DEFAULT_WORKSPACE_ID / DB default fallback behavior.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any, Dict, Optional

import requests


class MemoryLabApiError(RuntimeError):
    """Raised when API call fails or returns non-2xx response."""

    def __init__(
        self,
        message: str,
        *,
        method: Optional[str] = None,
        url: Optional[str] = None,
        status_code: Optional[int] = None,
        body: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.method = method
        self.url = url
        self.status_code = status_code
        self.body = body


@dataclass
class MemoryLabApiClient:
    base_url: str
    timeout_s: float = 15.0
    default_workspace_id: Optional[str] = None
    api_token: Optional[str] = None

    @staticmethod
    def from_env() -> "MemoryLabApiClient":
        host = os.getenv("MEMORY_LAB_API_HOST", "127.0.0.1")
        port = os.getenv("MEMORY_LAB_API_PORT", "8000")
        scheme = os.getenv("MEMORY_LAB_API_SCHEME", "http")
        if host not in {"127.0.0.1", "localhost"}:
            raise MemoryLabApiError(f"Unsafe host for local MCP plan: {host}")
        base_url = f"{scheme}://{host}:{port}".rstrip("/")
        default_workspace_id = os.getenv("MEMORY_LAB_MCP_DEFAULT_WORKSPACE_ID") or None
        api_token = os.getenv("MEMORY_LAB_API_TOKEN") or os.getenv("MEMORY_LAB_MCP_API_TOKEN") or None
        return MemoryLabApiClient(base_url=base_url, default_workspace_id=default_workspace_id, api_token=api_token)

    def _selected_workspace_id(self, workspace_id: Optional[str] = None) -> Optional[str]:
        explicit = workspace_id.strip() if isinstance(workspace_id, str) else workspace_id
        if explicit:
            return explicit
        default = self.default_workspace_id.strip() if isinstance(self.default_workspace_id, str) else self.default_workspace_id
        return default or None

    @staticmethod
    def redact_sensitive(value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        redacted = value
        patterns = [
            (r"Authorization\s*:\s*Bearer\s+[^\s,;]+", "Authorization: Bearer [REDACTED]"),
            (r"Bearer\s+[^\s,;]+", "Bearer [REDACTED]"),
            (r"(?i)(token|api[_-]?key|key|secret|password)=([^\s&]+)", r"\1=[REDACTED]"),
            (r"(?i)(\"(?:token|api[_-]?key|key|secret|password|authorization)\"\s*:\s*)\"[^\"]+\"", r"\1\"[REDACTED]\""),
        ]
        for pattern, replacement in patterns:
            redacted = re.sub(pattern, replacement, redacted)
        return redacted

    def _headers(self, workspace_id: Optional[str] = None) -> Dict[str, str]:
        headers: Dict[str, str] = {}
        selected = self._selected_workspace_id(workspace_id)
        if selected:
            headers["X-Workspace-ID"] = selected
        if self.api_token:
            headers["Authorization"] = f"Bearer {self.api_token}"
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json_body: Optional[Dict[str, Any]] = None,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = self._headers(workspace_id)
        try:
            resp = requests.request(
                method=method,
                url=url,
                params=params,
                json=json_body,
                headers=headers or None,
                timeout=self.timeout_s,
            )
        except requests.RequestException as exc:
            safe_exc = self.redact_sensitive(str(exc))
            raise MemoryLabApiError(
                f"Request failed for {method} {url}: {safe_exc}",
                method=method,
                url=url,
            ) from exc

        if resp.status_code < 200 or resp.status_code >= 300:
            safe_body = self.redact_sensitive(resp.text[:2000])
            raise MemoryLabApiError(
                f"Non-2xx from {method} {url}: {resp.status_code} body={safe_body[:500]}",
                method=method,
                url=url,
                status_code=resp.status_code,
                body=safe_body,
            )

        try:
            return resp.json()
        except ValueError as exc:
            raise MemoryLabApiError(
                f"Invalid JSON from {method} {url}",
                method=method,
                url=url,
                status_code=resp.status_code,
                body=self.redact_sensitive(resp.text[:2000]),
            ) from exc

    def health(self) -> Dict[str, Any]:
        return self._request("GET", "/health")

    def content_create_id(self, content: Optional[str] = None, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {}
        if content is not None:
            payload["content"] = content
        return self._request("POST", "/v1/content", json_body=payload, workspace_id=workspace_id)

    def content_get(self, content_id: str, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request("GET", f"/v1/content/{content_id}", workspace_id=workspace_id)

    def hub_create(
        self,
        title: str,
        hub_type: Optional[str] = None,
        description: Optional[str] = None,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"title": title}
        if hub_type is not None:
            payload["hub_type"] = hub_type
        if description is not None:
            payload["description"] = description
        return self._request("POST", "/v1/hubs", json_body=payload, workspace_id=workspace_id)

    def hub_get(self, hub_id: str, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request("GET", f"/v1/hubs/{hub_id}", workspace_id=workspace_id)

    def hub_link_content(self, hub_id: str, content_id: str, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request("POST", f"/v1/hubs/{hub_id}/links", json_body={"content_id": content_id}, workspace_id=workspace_id)

    def edge_create(
        self,
        source_hub_id: str,
        target_hub_id: str,
        edge_type: str,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return self._request(
            "POST",
            "/v1/edges",
            json_body={
                "source_hub_id": source_hub_id,
                "target_hub_id": target_hub_id,
                "edge_type": edge_type,
            },
            workspace_id=workspace_id,
        )

    def edge_get(self, edge_id: str, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request("GET", f"/v1/edges/{edge_id}", workspace_id=workspace_id)

    def edge_list(
        self,
        hub_id: Optional[str] = None,
        include_archived: Optional[bool] = None,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if hub_id is not None:
            params["hub_id"] = hub_id
        if include_archived is not None:
            params["include_archived"] = str(include_archived).lower()
        return self._request("GET", "/v1/edges", params=params, workspace_id=workspace_id)

    def edge_archive(self, edge_id: str, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request("POST", f"/v1/edges/{edge_id}/archive", workspace_id=workspace_id)

    def retrieval_search(self, query: str, limit: Optional[int] = None, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"query": query}
        if limit is not None:
            payload["limit"] = limit
        return self._request("POST", "/v1/retrieval/search", json_body=payload, workspace_id=workspace_id)

    def decision_create(self, payload: Dict[str, Any], workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request("POST", "/decisions/", json_body=payload, workspace_id=workspace_id)

    def decision_get(self, decision_id: str, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request("GET", f"/decisions/{decision_id}", workspace_id=workspace_id)

    def decision_list(
        self,
        status: Optional[str] = None,
        hub_id: Optional[str] = None,
        limit: Optional[int] = None,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        if hub_id is not None:
            params["hub_id"] = hub_id
        if limit is not None:
            params["limit"] = limit
        return self._request("GET", "/decisions/", params=params, workspace_id=workspace_id)

    def decision_update_status(self, decision_id: str, decision_status: str, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request(
            "PATCH",
            f"/decisions/{decision_id}/status",
            json_body={"decision_status": decision_status},
            workspace_id=workspace_id,
        )

    def decision_lineage(self, decision_id: str, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request("GET", f"/decisions/{decision_id}/lineage", workspace_id=workspace_id)

    def decision_conflicts(self, workspace_id: Optional[str] = None) -> Dict[str, Any]:
        return self._request("GET", "/decisions/conflicts", workspace_id=workspace_id)

    def decision_timeline(
        self,
        hub_id: Optional[str] = None,
        tags: Optional[str] = None,
        limit: Optional[int] = None,
        workspace_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if hub_id is not None:
            params["hub_id"] = hub_id
        if tags is not None:
            params["tags"] = tags
        if limit is not None:
            params["limit"] = limit
        return self._request("GET", "/decisions/timeline", params=params, workspace_id=workspace_id)
